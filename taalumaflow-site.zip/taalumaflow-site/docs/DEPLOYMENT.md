# Deployment Guide

## Static hosting (recommended)

The site is pure HTML/CSS/JS — no build step, no server required.

### GitHub Pages (free)
1. Push repo to GitHub
2. Settings → Pages → Source: Deploy from branch → `main` / `/ (root)`
3. Site live at `https://yourusername.github.io/taalumaflow-site/`
4. Add custom domain in Settings → Pages → Custom domain → `talumaflow.com`

### Netlify (free tier)
```bash
# Drag and drop the repo folder to netlify.com/drop
# Or connect GitHub repo for auto-deploy on push
```

### Cloudflare Pages (free tier)
```bash
# Connect GitHub repo in Cloudflare dashboard
# Build command: (none)
# Build output: / (root)
```

---

## Chat API — production proxy

The chat widget currently calls the Anthropic API directly from the browser.
This is fine for demos but exposes the API key in network requests.

**For production, proxy through your backend:**

### Django backend proxy (recommended if using TaalumaMail backend)

Add to `config/urls.py`:
```python
path('api/chat/', ChatProxyView.as_view()),
```

Create `erp/views_chat.py`:
```python
import httpx
from django.conf import settings
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny  # or IsAuthenticated for private

class ChatProxyView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        payload = request.data
        payload['model'] = 'claude-sonnet-4-6'
        payload['max_tokens'] = 1000

        with httpx.Client() as client:
            r = client.post(
                'https://api.anthropic.com/v1/messages',
                headers={
                    'x-api-key': settings.ANTHROPIC_API_KEY,
                    'anthropic-version': '2023-06-01',
                    'content-type': 'application/json',
                },
                json=payload,
                timeout=30,
            )
        return Response(r.json(), status=r.status_code)
```

Add to `.env`:
```
ANTHROPIC_API_KEY=sk-ant-...
```

Then update `src/js/chat.js` — change the fetch URL:
```js
// Was:
const res = await fetch('https://api.anthropic.com/v1/messages', { ... })

// Change to:
const res = await fetch('/api/chat/', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ messages }),  // system prompt stays server-side
})
```

### Formspree (contact form)

Replace the mock form handler in `src/js/ui.js` `initContactForm()`:
```js
// Replace the setTimeout mock with:
const res = await fetch('https://formspree.io/f/YOUR_FORM_ID', {
  method: 'POST',
  headers: { 'Accept': 'application/json' },
  body: new FormData(form),
});
if (res.ok) {
  btn.textContent = 'Message sent ✓';
  // ...
}
```

---

## Environment variables

Copy `.env.example` to `.env` and fill in values.
Never commit `.env` to git — it is in `.gitignore`.

```
ANTHROPIC_API_KEY=sk-ant-...   # Only needed if using backend proxy
```
