# TaalumaFlow — Company Website

Marketing and product site for [TaalumaFlow](https://www.talumaflow.com),
an AI automation company based in Milan, Italy.

## Structure

```
taalumaflow-site/
├── index.html              ← Entry point (no build step required)
├── src/
│   ├── css/
│   │   └── main.css        ← All styles (CSS variables for dark/light)
│   └── js/
│       ├── index.js        ← App entry point — wires all modules to DOM
│       ├── particles.js    ← Animated background canvas
│       ├── theme.js        ← Dark/light mode toggle + localStorage
│       ├── chat.js         ← AI chat logic (inline demo + floating bubble)
│       ├── chatPrompt.js   ← System prompt — edit this to update bot knowledge
│       └── ui.js           ← Nav, scroll reveal, counters, form, charts
├── public/
│   └── (favicon, og-image, any static assets)
├── docs/
│   ├── DEPLOYMENT.md       ← How to deploy + proxy the chat API
│   └── CUSTOMISATION.md    ← How to update content, colors, products
├── .gitignore
├── .env.example
└── README.md
```

## Running locally

No build step. Open `index.html` directly in a browser, or serve with any static server:

```bash
# Python
python -m http.server 3000

# Node
npx serve .

# VS Code
# Install "Live Server" extension, right-click index.html → Open with Live Server
```

## Chat functionality

The AI chat widget calls the Anthropic API. For local development,
a proxy is already handled by the API. For production deployment,
see `docs/DEPLOYMENT.md` for instructions on routing through your
own backend so the API key is never exposed client-side.

To update what the chatbot knows, edit `src/js/chatPrompt.js`.

## Theme

Dark mode is the default. The toggle in the nav switches to light mode
and persists the preference to `localStorage`.

All colours are CSS custom properties defined at the top of `src/css/main.css`
under `[data-theme="dark"]` and `[data-theme="light"]`.

## Deploying to GitHub Pages

```bash
# Push to main branch, then in GitHub:
# Settings → Pages → Source: Deploy from branch → main / root
```

The site is static HTML — no build step, no Node, no dependencies beyond
Google Fonts (loaded via CDN).

## Contact

- Email: talumaflow@gmail.com
- WhatsApp: +39 328 9741517
- Web: www.talumaflow.com
- Social: @talumaflow
